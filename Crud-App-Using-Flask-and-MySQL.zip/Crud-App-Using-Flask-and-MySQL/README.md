# Crud-App-Using-Flask-and-MySQL

This is the project implementation which is done for CMPE 321 Introduction to Database Systems at Bogazici University.  

#### Project Description

Project description can be found [here](https://github.com/safakozdek/Crud-App-Using-Flask-and-MySQL/blob/master/Description.pdf).

#### Project Subparts

* [Frontend Templates](https://github.com/safakozdek/Crud-App-Using-Flask-and-MySQL/tree/master/Code/templates)

* [Flask Backend](https://github.com/safakozdek/Crud-App-Using-Flask-and-MySQL/blob/master/Code/app.py)

